-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 19, 2020 at 01:08 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `familypharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `drugs`
--

CREATE TABLE `drugs` (
  `id` int(11) NOT NULL,
  `namaObat` varchar(255) NOT NULL,
  `jenisObat` varchar(255) NOT NULL,
  `produsenObat` varchar(255) DEFAULT NULL,
  `stokObat` smallint(6) DEFAULT '0',
  `hargaObat` int(11) NOT NULL,
  `fotoObat` varchar(255) DEFAULT 'noPhoto.jpg',
  `descObat` text NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `drugs`
--

INSERT INTO `drugs` (`id`, `namaObat`, `jenisObat`, `produsenObat`, `stokObat`, `hargaObat`, `fotoObat`, `descObat`, `createdAt`, `updatedAt`) VALUES
(52, 'Kloroquin', 'Obat Corona', 'Kimia Farma', 200, 200000, 'http://localhost:3001/uploads\\1587293525006chloroquine.jpg', 'Obat ini ampuh digunakan sebagai obat corona. Namun belum ada pengujian yang pasti tetapi dipercaya sebagai obat corona\n', '2020-04-19 10:52:05', '2020-04-19 10:52:05'),
(53, 'Avigan', 'Obat Corona', 'Genttarais', 300, 300000, 'http://localhost:3001/uploads\\1587293695461avigan.jpg', 'Favipiravir, atau yang dikenal dengan nama Avigan dan favilavir adalah obat antivirus yang dikembangkan oleh Toyama Chemical. Obat ini memiliki aktivitas melawan berbagai virus RNA. Senyawa antivirus ini merupakan turunan dari pirazinkarboksamida.', '2020-04-19 10:54:55', '2020-04-19 10:54:55'),
(54, 'Paracetamol', 'Obat Panas', 'Kalbe', 100, 12000, 'http://localhost:3001/uploads\\1587293908730parasetamol-aladokter.jpg', 'Parasetamol atau asetaminofen adalah obat analgesik dan antipiretik yang populer dan digunakan untuk melegakan sakit kepala, sengal-sengal dan sakit ringan, serta demam. Digunakan dalam sebagian besar resep obat analgesik selesma dan flu.', '2020-04-19 10:58:28', '2020-04-19 11:04:40'),
(55, 'Rendesivir', 'Obat Virus', 'Koolaienie', 20, 400000, 'http://localhost:3001/uploads\\1587294024053remdesivir.png', 'Remdesivir adalah obat antivirus, sebuah prodrug analog nukleotida baru, yang dikembangkan oleh perusahaan bioteknologi Gilead Sciences sebagai pengobatan untuk infeksi penyakit virus Ebola', '2020-04-19 11:00:24', '2020-04-19 11:00:24'),
(56, 'Alkohol 70%', 'Cairan', 'Orang Tua', 300, 8000, 'http://localhost:3001/uploads\\1587294100067alkhol.jpg', 'Alkohol 70% digunakan sebagai desinfektan dengan membunuh bakteri di permukaan kulit. Alkohol penting untuk mengobati infeksi dan sebagai pertolongan pertama untuk mencegah penyebaran infeksi.', '2020-04-19 11:01:40', '2020-04-19 11:01:40'),
(57, 'Amoksisilin', 'Antibiotik', 'Kalbe', 100, 32000, 'http://localhost:3001/uploads\\1587294376548maxresdefault.jpg', 'Amoksisilin merupakan antibiotik yang digunakan dalam pengobatan berbagai infeksi bakteri. Obat ini merupakan lini pertama untuk pengobatan infeksi telinga tengah. Obat ini juga dapat digunakan untuk mengobati faringitis streptokokus, pneumonia, infeksi kulit, dan infeksi saluran kemih.', '2020-04-19 11:06:16', '2020-04-19 11:06:16');

-- --------------------------------------------------------

--
-- Table structure for table `includes`
--

CREATE TABLE `includes` (
  `id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `harga` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `orderId` int(11) DEFAULT NULL,
  `drugId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `totalHarga` int(11) DEFAULT '0',
  `totalQuantity` int(11) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `userId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `totalHarga`, `totalQuantity`, `createdAt`, `updatedAt`, `userId`) VALUES
(1, 1200000, 4, '2020-04-13 10:39:38', '2020-04-13 10:39:38', 4),
(2, 300000, 1, '2020-04-13 10:39:42', '2020-04-13 10:39:42', 4),
(3, 300, 1, '2020-04-13 10:39:45', '2020-04-13 10:39:45', 4),
(4, 1200300, 5, '2020-04-13 11:00:51', '2020-04-13 11:00:51', 4),
(5, 20000, 1, '2020-04-14 06:43:00', '2020-04-14 06:43:00', 4);

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `hari` varchar(255) NOT NULL,
  `jamMasuk` time NOT NULL,
  `jamKeluar` time NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `userId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `hari`, `jamMasuk`, `jamKeluar`, `createdAt`, `updatedAt`, `userId`) VALUES
(4, 'Minggu', '08:00:00', '12:00:00', '2020-04-14 16:22:59', '2020-04-14 16:34:06', 5),
(5, 'Senin', '08:00:00', '17:00:00', '2020-04-14 16:29:07', '2020-04-14 16:29:07', 5);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `namaUser` varchar(255) NOT NULL,
  `umurUser` int(11) DEFAULT NULL,
  `alamatUser` varchar(255) NOT NULL,
  `notelpUser` varchar(255) NOT NULL,
  `emailUser` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `statusUser` smallint(6) DEFAULT '0',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `namaUser`, `umurUser`, `alamatUser`, `notelpUser`, `emailUser`, `username`, `password`, `statusUser`, `createdAt`, `updatedAt`) VALUES
(4, 'abisatria cakep', 22, 'Jl bojongsoang', '081209381204', 'kadekaaaa@gmail.com', 'abisatria2', '$2b$10$90Ow7jj5fx5GLLvECL/2YuEj1HzgrpChc3ECxtAeu2GnnTJ1tR/bm', 1, '2020-04-08 10:51:42', '2020-04-10 14:44:23'),
(5, 'kadek', 33, 'jl lembusora', '082146432578', 'kadek@gmail.com', 'kadek123', '$2b$10$17YN84sWWETPj/aOT1C9Ne9nLpUhvzwhHhAQDon2dXHPc0S1TCTLC', 0, '2020-04-14 07:36:10', '2020-04-14 07:36:10'),
(6, 'jono saputra', 33, 'jl ayani 20000', '12313121321', 'jono_saputra@gmail.com', 'jono_saputra', '$2b$10$w.ZzSpGkosrt/b/hczGuIeInhtagH2KXytnHdQ9sWfBH4Wm8V36Cq', 0, '2020-04-16 15:01:14', '2020-04-16 15:01:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `drugs`
--
ALTER TABLE `drugs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `includes`
--
ALTER TABLE `includes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderId` (`orderId`),
  ADD KEY `drugId` (`drugId`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `emailUser` (`emailUser`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `drugs`
--
ALTER TABLE `drugs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `includes`
--
ALTER TABLE `includes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `includes`
--
ALTER TABLE `includes`
  ADD CONSTRAINT `includes_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `includes_ibfk_2` FOREIGN KEY (`drugId`) REFERENCES `drugs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
